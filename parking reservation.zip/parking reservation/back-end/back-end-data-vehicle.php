<?php

    // DB Connection
    include '../config/config.php';

    // Class Function
    class vehicle extends Connection{ 

        // Ingoing Vehicle Function
        public function manageingoingvehicle(){
            $sqlselect_arrival = "SELECT * FROM tbl_customers WHERE status = 'Arrival'";
            $arrival = $this->conn()->query($sqlselect_arrival); 
            $arrival->execute();
            return $arrival->fetchAll();  
        }

        // Ingoing Total Vehicle Function
        public function manageingoingtotalvehicle(){
            $sqlselect_total_arrival = "SELECT COUNT(customers_id) AS total FROM tbl_customers WHERE status = 'Arrival'";
            $totalarrival = $this->conn()->query($sqlselect_total_arrival); 
            $totalarrival->execute();
            return $totalarrival->fetchAll();  
        }

        // Outgoing Vehicle Function
        public function manageoutgoingvehicle(){
            $sqlselect_departured = "SELECT * FROM tbl_customers WHERE status = 'Departured'";
            $departured = $this->conn()->query($sqlselect_departured); 
            $departured->execute();
            return $departured->fetchAll();   
        }

        // Outgoing Total Vehicle Function
        public function manageoutgoingtotalvehicle(){
            $sqlselect_total_departured = "SELECT COUNT(customers_id) AS total FROM tbl_customers WHERE status = 'Departured'";
            $totaldepartured = $this->conn()->query($sqlselect_total_departured); 
            $totaldepartured->execute();
            return $totaldepartured->fetchAll();   
        }

        // Report Data Vehicle Function
        public function managereportdata(){
            $sqlselect_report = "SELECT * FROM tbl_customers";
            $report = $this->conn()->query($sqlselect_report); 
            $report->execute();
            return $report->fetchAll();   
        }

        // Total Data Vehicle Function
        public function managetotalparked(){
            $sqlselect_report = "SELECT COUNT(customers_id) AS total FROM tbl_customers";
            $totalparked = $this->conn()->query($sqlselect_report); 
            $totalparked->execute();
            return $totalparked->fetchAll();   
        }

        // Total Earnings Function
        public function managetotalearnings(){
            $sqlselect_earnings = "SELECT balance FROM balance";
            $totalearnings = $this->conn()->query($sqlselect_earnings); 
            $totalearnings->execute();
            return $totalearnings->fetchAll();   
        }
    }

    $vehicle = new vehicle();
   
?>