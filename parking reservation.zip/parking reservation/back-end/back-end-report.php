<?php


// Insert Data For New Vehicle
include '../config/config.php';
class report extends Connection{
  public function managereport(){
    if (isset($_POST['search'])) {
      $start_date = $_POST['start_date'];
      $end_date = $_POST['end_date'];
      $sqlselect = "SELECT * FROM tbl_customers WHERE test_date BETWEEN '$start_date' AND '$end_date' ORDER BY test_date";
      $result = $this->conn()->query($sqlselect); 
      $result->execute();
      return $result->fetchAll();
    }
  }
}
$new_vehicle = new report();
$new_vehicle->managereport();

?>