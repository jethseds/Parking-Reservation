<?php

    // DB Connection
    include '../config/config.php';

    // Class Function
    class vehicle extends Connection{ 

        // Ingoing Vehicle Function
        public function manageingoingvehicle(){
            $sqlselect_arrival = "SELECT * FROM tbl_customers WHERE customers_id = '".$_GET['id']."'";
            $arrival = $this->conn()->query($sqlselect_arrival); 
            $arrival->execute();
            return $arrival->fetchAll();  
        }

        // Outgoing Vehicle Function
        public function manageoutgoingvehicle(){
            $sqlselect_departured = "SELECT * FROM tbl_customers WHERE customers_id = '".$_GET['id']."'";
            $departured = $this->conn()->query($sqlselect_departured); 
            $departured->execute();
            return $departured->fetchAll();   
        }

        // Report Data Vehicle Function
        public function managereportdata(){
            $sqlselect_report = "SELECT * FROM tbl_customers";
            $report = $this->conn()->query($sqlselect_report); 
            $report->execute();
            return $report->fetchAll();   
        }
    }
    $vehicle = new vehicle();
    $vehicle->manageingoingvehicle();
    $vehicle->manageoutgoingvehicle();
    $vehicle->managereportdata();
    
?>