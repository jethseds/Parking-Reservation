<?php

    // DB Connection
    include '../config/config.php';

    // Class Function
    class admin extends Connection{ 

        // Ingoing Vehicle Function
        public function manageadmin(){
            $sqlselect_arrival = "SELECT * FROM tbl_admin";
            $dataadmin = $this->conn()->query($sqlselect_arrival); 
            $dataadmin->execute();
            return $dataadmin->fetchAll();  
        }

    }
    $admin = new admin();
    $admin->manageadmin();
    
?>