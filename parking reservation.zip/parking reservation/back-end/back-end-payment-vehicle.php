<?php

// Update Data For Payment Vehicle
include '../config/config.php';
class new_vehicle2 extends Connection{
  public function manage_new_vehicle2(){
    if (isset($_POST['payment'])) {
        
        // Update Data For Payment Customer Vehicle Function
        $id = $_POST['id'];
        $charge = $_POST['charge'];
        date_default_timezone_set('Asia/Manila');
        $time_d = date('F j, Y g:i:a  ');
        $status = 'Departured';
        
        $sqlinsert = "UPDATE tbl_customers SET payment = ?, time_d = ?, status = ? WHERE customers_id = '".$id."'";
        $statementinsert = $this->conn()->prepare($sqlinsert);
        $statementinsert->bindParam(1, $payment);
        $statementinsert->bindParam(2, $time_d);
        $statementinsert->bindParam(3, $status);
        $statementinsert->execute([$charge,$time_d,$status]);
        
        
        // Update Earnings Company Vehicle Function
        $sqlselect_earnings = "SELECT balance FROM balance";
        $totalearnings = $this->conn()->query($sqlselect_earnings); 
        while ($row = $totalearnings->fetch()) {

            $balance = $row['balance'] + $charge; 

            $sqlinsert = "UPDATE balance SET balance = ? WHERE balance_id = '1'";
            $statementinsert = $this->conn()->prepare($sqlinsert);
            $statementinsert->bindParam(1, $balance);
            $statementinsert->execute([$balance]);

        }

        // Redirect After Payment Function
        header('location:../admin/outgoing-vehicle.php');
      
    }
  }
}

$new_vehicle = new new_vehicle2();
$new_vehicle->manage_new_vehicle2();

?>