<?php

// Insert Data For New Vehicle
include '../config/config.php';
class new_vehicle extends Connection{
  public function manage_new_vehicle(){
    if (isset($_POST['new-vehicle'])) {
      $serial = rand(00000,99999);
      $sqlselect = "SELECT * FROM tbl_customers WHERE serial = ?";
      $statementselect = $this->conn()->prepare($sqlselect);
      $statementselect->execute([$serial]);
      if ($statementselect->rowcount() > 0) {
        header('location:../admin/new-vehicle.php?error=vehicle already Ingoing');
      }else{
        $fullname = $_POST['fullname'];
        $park = $_POST['park'];
        $plot = $_POST['plot'];
        $model = $_POST['model'];
        $plate_number = $_POST['plate_number'];
        $phone_number = $_POST['phone_number'];
        date_default_timezone_set('Asia/Manila');
        $time_a = date('F j, Y g:i:a  ');
        $date = date('Y-m-d');
        $status = 'Arrival';

        $sqlinsert = "INSERT INTO tbl_customers(serial,fullname,phone_number,park,plot,model,num_plate,time_a,test_date,status)VALUES(?,?,?,?,?,?,?,?,?,?)";
        $statementinsert = $this->conn()->prepare($sqlinsert);
        $statementinsert->bindParam(1, $fullname);
        $statementinsert->bindParam(2, $park);
        $statementinsert->bindParam(3, $plot);
        $statementinsert->bindParam(4, $model);
        $statementinsert->bindParam(5, $plate_number);
        $statementinsert->bindParam(6, $phone_number);
        $statementinsert->bindParam(7, $serial);
        $statementinsert->bindParam(8, $time_a);
        $statementinsert->bindParam(9, $date);
        $statementinsert->bindParam(10, $status);
        $statementinsert->execute([$serial,$fullname,$phone_number,$park,$plot,$model,$plate_number,$time_a,$date,$status]);
        header('location:../admin/new-vehicle.php?success=Successfully Added');
      }
    }
  }
}

$new_vehicle = new new_vehicle();
$new_vehicle->manage_new_vehicle();

?>