<?php

// Update Data For Payment Vehicle
include '../config/config.php';
class new_vehicle2 extends Connection{
  public function manage_new_vehicle2(){
    if (isset($_POST['update'])) {

        $id = '1';
        $username = $_POST['username'];
        $phone_number = $_POST['phone_number'];
        $email = $_POST['email'];

        $sqlinsert = "UPDATE tbl_admin SET username = ?, phone_number = ?, email = ? WHERE admin_id = '".$id."'";
        $statementinsert = $this->conn()->prepare($sqlinsert);
        $statementinsert->bindParam(1, $username);
        $statementinsert->bindParam(2, $phone_number);
        $statementinsert->bindParam(3, $email);
        $statementinsert->execute([$username,$phone_number,$email]);
        header('location:../admin/profile.php');
      
    }
  }
}

$new_vehicle = new new_vehicle2();
$new_vehicle->manage_new_vehicle2();

?>