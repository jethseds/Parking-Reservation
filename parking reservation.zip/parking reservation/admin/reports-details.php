<?php
    include '../back-end/back-end-report.php';
    $result = new report(); 
    $query = $result->managereport();
?>

<!DOCTYPE html>
<html lang="en">

<style type="text/css">
.sidebar .nav-item.active-reports .nav-link {
    font-weight: 700;
}
</style>

    <body>
        <div id="wrapper">
            <div id="nav-menu"></div>
            <div id="content-wrapper" class="d-flex flex-column">
                <div id="content">
                    <div id="nav-header"></div>

                    <div class="container-fluid">

                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800">Reports</h1>
                        </div>

                        <!-- DataTales Example -->
                        <div class="card shadow mb-4 my-5">
                            <div class="card-header py-3" style="background-image: linear-gradient(to right, #f3306a , #ec7b07);">
                                <div class="row">
                                    <h6 class="m-0 font-weight-bold text-white">Reports</h6>
                                </div>
                            </div>

                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Parking No</th>
                                                <th>User</th>
                                                <th>Plate No.</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                       
                                        <!-- Back End Function -->
                                        <?php $id = 1; foreach((array) $query as $row) { ?>

                                        <tbody>
                                            <tr>
                                                <td><?php echo $id; ?></td>
                                                <td><?php echo $row['serial']; ?></td>
                                                <td><?php echo $row['fullname']; ?></td>
                                                <td><?php echo $row['num_plate']; ?></td>
                                                <td>
                                                    <?php if ($row['status'] == 'Arrival') { ?>
                                                        <a href="view-ingoing.php?id=<?php echo $row['customers_id']; ?>" class="text-dark">View</a>
                                                        
                                                   <?php }else{ ?>
                                                    <a href="view-outgoing.php?id=<?php echo $row['customers_id']; ?>" class="text-dark">View</a></td>
                                            </tr>
                                        </tbody>

                                        <!-- Back End Function -->
                                        <?php $id++; } } ?>

                                    </table>
                                </div>
                            </div>
                        </div>
                        
                    </div>

                    <!-- Copyright of Parking Reservation System -->
                    <div class="bg-white h-100 m-4 mt-5 p-3 pl-3">
                        <small>Copyright © 2021</small>
                        <small class="float-right">Parking Reservation System</small>
                    </div>
                </div>
            </div>
        </div>
        <script src="../vendor/jquery/jquery.min.js"></script>
        <script> 

            // Show Nav Menu And Header
            $(function(){
              $("#nav-menu").load("../nav/nav.php",); 
              $("#nav-header").load("../nav/header.php"); 
            });

            // FadeIn Content
            $('body').fadeOut(0);
            $('body').fadeIn(2000);
           
        </script>
    </body>

</html>