<?php
    include '../back-end/back-end-single-data-vehicle.php';
    $result = new vehicle(); 
    $query = $result->manageoutgoingvehicle();
?>

<!DOCTYPE html>
<html lang="en">

<style type="text/css">
.sidebar .nav-item.active-manage-vehicle .nav-link {
    font-weight: 700;
}
</style>

    <body>
        <div id="wrapper">
            <div id="nav-menu"></div>
            <div id="content-wrapper" class="d-flex flex-column">
                <div id="content">
                    <div id="nav-header"></div>

                    <div class="container-fluid">

                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800">Out Departured Vehicle</h1>
                        </div>

                         <!-- DataTales Example -->
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card shadow mb-4 my-5">
                                    <div class="card-header py-3" style="background-image: linear-gradient(to right, #f3306a , #ec7b07);">
                                        <h6 class="m-0 font-weight-bold text-white">DataTables Of In Going Vehicle</h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive">

                                            <!-- Back End Function -->
                                            <?php $id = 1; foreach($query as $row) { ?>

                                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                                <thead>
                                                    
                                                        <tr>
                                                            <th>S.No</th>
                                                            <td><?php echo $id; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th>Parking No</th>
                                                            <td><?php echo $row['serial']; ?></td>
                                                        </tr>
                                                        <tr>
                                                          <th>User</th>  
                                                          <td><?php echo $row['fullname']; ?></td>
                                                        </tr>
                                                        <tr>
                                                          <th>Phone Number</th>  
                                                          <td><?php echo $row['phone_number']; ?></td>
                                                        </tr>
                                                        <tr>
                                                          <th>Park</th>  
                                                          <td><?php echo $row['park']; ?></td>
                                                        </tr>
                                                        <tr>
                                                          <th>Plot</th>  
                                                          <td><?php echo $row['plot']; ?></td>
                                                        </tr>
                                                        <tr>
                                                          <th>Model</th>  
                                                          <td><?php echo $row['model']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th>Plate Number</th>
                                                            <td><?php echo $row['num_plate']; ?></td>
                                                        </tr>
                                                        <tr>
                                                          <th>Time Arrival</th>  
                                                          <td><?php echo $row['time_a']; ?></td>
                                                        </tr>
                                                        <tr>
                                                          <th>Time Arrival</th>  
                                                          <td><?php echo $row['time_d']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th>Charge</th>
                                                            <td><?php echo $row['payment']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th>Status</th>
                                                            <td><?php echo $row['status']; ?></td>
                                                        </tr>
                                                </thead>
                                            </table>

                                            <!-- Back End Function -->
                                            <?php $id++; } ?>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6"></div>
                        </div>
                    </div>

                    <!-- Copyright of Parking Reservation System -->
                    <div class="bg-white h-100 m-4 mt-5 p-3 pl-3">
                        <small>Copyright © 2021</small>
                        <small class="float-right">Parking Reservation System</small>
                    </div>

                </div>
            </div>
        </div>
        <script src="../vendor/jquery/jquery.min.js"></script>
        <script> 

            // Show Nav Menu And Header
            $(function(){
              $("#nav-menu").load("../nav/nav.php",); 
              $("#nav-header").load("../nav/header.php"); 
            });

            // FadeIn Content
            $('body').fadeOut(0);
            $('body').fadeIn(2000);
           
        </script>
    </body>

</html>