<!DOCTYPE html>
<html lang="en">
    <body>
        <div id="wrapper">
            <div id="nav-menu"></div>
            <div id="content-wrapper" class="d-flex flex-column">
                <div id="content">
                    <div id="nav-header"></div>

                    <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Change Password</h1>
                    </div>

                    <div class="container m-0 p-0 col-lg-4">

        <div class="card o-hidden border-1 my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg-12">
                        <div>
                            <div class="text-center p-2" style="background-image: linear-gradient(to right, #f3306a , #ec7b07);">
                                <h1 class="h4 text-white">Change Password</h1>
                            </div>
                            <form method="POST" class="user m-3">
                                    <div class="form-group mb-3 mb-sm-0">
                                        <label>Current Password</label>
                                        <input type="password" class="form-control rounded-0" id="exampleFirstName"
                                            placeholder="Current Password..." required>
                                    </div>
                                    <div class="form-group mt-3">
                                        <label>New Password</label>
                                        <input type="password" class="form-control rounded-0" id="exampleLastName"
                                            placeholder="New Password..." required>
                                    </div>
                                    <div class="form-group mt-3">
                                        <label>Confirm Password</label>
                                        <input type="password" class="form-control rounded-0" id="exampleLastName"
                                            placeholder="Confirm Password..." required>
                                    </div>
                                <button  class="btn btn-primary">
                                    Change
                                </button>
                               
                            </form>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
                   

                </div>

                <div class="bg-white h-100 m-4 mt-5 p-3 pl-3">
                    <small>Copyright © 2021</small>
                    <small class="float-right">Parking Reservation System</small>
                </div>
                </div>
            </div>


        </div>
        <script src="../vendor/jquery/jquery.min.js"></script>
        <script> 

            // Show Nav Menu And Header
            $(function(){
              $("#nav-menu").load("../nav/nav.php",); 
              $("#nav-header").load("../nav/header.php"); 
            });

            // FadeIn Content
            $('body').fadeOut(0);
            $('body').fadeIn(2000);
           
        </script>
    </body>

</html>