<?php  
 function fetch_data()  
 {  
      $output = '';  
      $conn = mysqli_connect("localhost", "root", "123", "db_parking_reservation");  
      $sql = "SELECT * FROM tbl_customers WHERE customers_id = '".$_GET['id']."'";  
      $result = mysqli_query($conn, $sql);      
      while($row = mysqli_fetch_array($result))  
      {       
      $output .= ' 
                  <tr>
                    <th style="font-weight:bold;">Id</th>
                    <td>'.$row["customers_id"].'</td> 
                    <th style="font-weight:bold;">Serial</th>
                    <td>'.$row["serial"].'</td> 
                  </tr>

                  <tr>
                    <th style="font-weight:bold;">Full Name</th>
                    <td>'.$row["fullname"].'</td> 
                    <th style="font-weight:bold;">Phone</th>
                    <td>'.$row["phone_number"].'</td> 
                  </tr>

                  <tr>
                    <th style="font-weight:bold;">Park</th>
                    <td>'.$row["park"].'</td> 
                    <th style="font-weight:bold;">Plot</th>
                    <td>'.$row["plot"].'</td> 
                  </tr>

                  <tr>
                    <th style="font-weight:bold;">Model</th>
                    <td>'.$row["model"].'</td> 
                    <th style="font-weight:bold;">Plate No.</th>
                    <td>'.$row["num_plate"].'</td> 
                  </tr>

                  <tr>
                    <th style="font-weight:bold;">Payment</th>
                    <td>'.$row["payment"].'</td> 
                    <th style="font-weight:bold;">Time Arrrival</th>
                    <td>'.$row["time_a"].'</td> 
                  </tr>

                  <tr>
                    <th style="font-weight:bold;">Time Departured</th>
                    <td>'.$row["time_d"].'</td> 
                    <th style="font-weight:bold;">Status</th>
                    <td>'.$row["status"].'</td> 
                  </tr>
      

                        
                       
                           
                         
                          ';  
      }  
      return $output;  
 }  
 if(isset($_POST["generate_pdf"]))  
 {  
      require_once('../tcpdf/tcpdf.php');  
      $obj_pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);  
      $obj_pdf->SetCreator(PDF_CREATOR);  
      $obj_pdf->SetTitle("Online Vehicle Parking Reservation System");  
      $obj_pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);  
      $obj_pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));  
      $obj_pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));  
      $obj_pdf->SetDefaultMonospacedFont('helvetica');  
      $obj_pdf->SetFooterMargin(PDF_MARGIN_FOOTER);  
      $obj_pdf->SetMargins(PDF_MARGIN_LEFT, '10', PDF_MARGIN_RIGHT);  
      $obj_pdf->setPrintHeader(false);  
      $obj_pdf->setPrintFooter(false);  
      $obj_pdf->SetAutoPageBreak(TRUE, 10);  
      $obj_pdf->SetFont('helvetica', '', 11);  
      $obj_pdf->AddPage();  
      $content = '';  
      $content .= '  
      <h4 align="center">Online Vehicle Parking Reservation System</h4><br /> 
      <table border="1" cellspacing="0" cellpadding="3">  
         
        
      ';  
      $content .= fetch_data();  
      $content .= '</table>';  
      $obj_pdf->writeHTML($content);  
      $obj_pdf->Output('file.pdf', 'I');  
 }  
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Online Vehicle Parking Reservation System</title>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />   

          <!-- Custom fonts for this template-->
          <link href="../vendor/fontawesome-free/css/all.min.css?v=<?php echo time() ?>" rel="stylesheet" type="text/css">
      </head>  
      <body>  
           <br />
           <div class="container">  
                <h4 align="center">Online Vehicle Parking Reservation System</h4><br />  
                <div class="table-responsive">  
                    <div class="col-md-12" align="right">
                     <form method="post">  
                      <button type="submit" name="generate_pdf" class="btn" style="color: white;background-image: linear-gradient(to right, #f3306a , #ec7b07);">
                        <i class="far fa-file-pdf"></i> Print
                      </button>
                     </form>  
                     </div>
                     <br/>
                     <br/>
                     <table class="table table-bordered">  
                   
                  
                     <?php  
                     echo fetch_data();  
                     ?>  
                     </table>  
                </div>  
           </div>  
      </body>  
</html>