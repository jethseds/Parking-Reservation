<?php
    include '../back-end/back-end-data-admin.php';
    $result = new admin(); 
    $query = $result->manageadmin();
?>

<!DOCTYPE html>
<html lang="en">
    <body>
        <div id="wrapper">
            <div id="nav-menu"></div>
            <div id="content-wrapper" class="d-flex flex-column">
                <div id="content">
                    <div id="nav-header"></div>

                    <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">My Profile</h1>
                    </div>

                    <div class="container m-0 p-0 col-lg-4">

        <div class="card o-hidden border-1 my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg-12">
                        <div>
                            <div class="text-center p-2" style="background-image: linear-gradient(to right, #f3306a , #ec7b07);">
                                <h1 class="h4 text-white">Profile</h1>
                            </div>
                            <form action="../back-end/back-end-profile.php" method="POST" class="user m-3">

                                <!-- Back End Function -->
                                <?php $id = 1; foreach($query as $row) { ?>
                                        
                                <div class="form-group mb-3 mb-sm-0">
                                    <label>Username</label>
                                    <input type="text" name="username" value="<?php echo $row['username']; ?>" class="form-control rounded-0" id="exampleFirstName"
                                        placeholder="Username..." required>
                                </div>
                                <div class="form-group mt-3">
                                    <label>Phone Number</label>
                                    <input type="text" name="phone_number" value="<?php echo $row['phone_number']; ?>" class="form-control rounded-0" id="exampleLastName"
                                        placeholder="Phone Number..." required>
                                </div>
                                <div class="form-group mt-3">
                                    <label>Email</label>
                                    <input type="email" name="email" value="<?php echo $row['email']; ?>" class="form-control rounded-0" id="exampleLastName"
                                        placeholder="Email..." required>
                                </div>
                                <button name="update" class="btn btn-primary">
                                    Update
                                </button>

                                <!-- Back End Function -->
                                <?php $id++; } ?>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
                   

                </div>

                <div class="bg-white h-100 m-4 mt-5 p-3 pl-3">
                    <small>Copyright © 2021</small>
                    <small class="float-right">Parking Reservation System</small>
                </div>
                </div>
            </div>


        </div>
        <script src="../vendor/jquery/jquery.min.js"></script>
        <script> 

            // Show Nav Menu And Header
            $(function(){
              $("#nav-menu").load("../nav/nav.php",); 
              $("#nav-header").load("../nav/header.php"); 
            });

            // FadeIn Content
            $('body').fadeOut(0);
            $('body').fadeIn(2000);
           
        </script>
    </body>

</html>