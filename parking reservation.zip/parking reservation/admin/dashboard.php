<?php
    include 'session.php';
    include '../back-end/back-end-data-vehicle.php';
    $result = new vehicle(); 
    $query_ingoing = $result->manageingoingtotalvehicle();
    $query_outgoing = $result->manageoutgoingtotalvehicle();
    $query_totalparked = $result->managetotalparked();
    $query_totalearnings = $result->managetotalearnings();
?>
<!DOCTYPE html>
<html lang="en">

<style type="text/css">
.sidebar .nav-item.active-dashboard .nav-link {
    font-weight: 700;
}
</style>

    <body>
        <div id="wrapper">
            <div id="nav-menu"></div>
            <div id="content-wrapper" class="d-flex flex-column">
                <div id="content">
                    <div id="nav-header"></div>

                    <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                    </div>

                    <div class="row">
                        <!-- Ingoing Vehicle Card -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-white text-uppercase mb-1">
                                                Ingoing Vehicle</div>
                                            <div class="h5 mb-0 font-weight-bold text-white">

                                                <!-- Back End Function -->
                                                <?php foreach($query_ingoing as $row) { echo $row['total']; } ?>

                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-car fa-2x text-white"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Outgoing Vehicle Card -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-white text-uppercase mb-1">Outgoing Vehicle
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-white">

                                                        <!-- Back End Function -->
                                                        <?php foreach($query_outgoing as $row) { echo $row['total']; } ?>

                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-car fa-2x text-white"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Pending Requests Card -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-white text-uppercase mb-1">
                                                Customers Parked</div>
                                            <div class="h5 mb-0 font-weight-bold text-white">

                                                <!-- Back End Function -->
                                                <?php foreach($query_totalparked as $row) { echo $row['total']; } ?>

                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-car fa-2x text-white"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Total Earnings Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-white text-uppercase mb-1">
                                                Total Earnings</div>
                                            <div class="h5 mb-0 font-weight-bold text-white">

                                                <!-- Back End Function -->
                                                <?php foreach($query_totalearnings as $row) { echo $row['balance']; } ?>
                                                    
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-calendar fa-2x text-white"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                   

                </div>

                <div class="bg-white h-100 m-4 mt-5 p-3 pl-3">
                    <small>Copyright © 2021</small>
                    <small class="float-right">Parking Reservation System</small>
                </div>
                </div>
            </div>


        </div>
        <script src="../vendor/jquery/jquery.min.js"></script>
        <script> 

            // Show Nav Menu And Header
            $(function(){
              $("#nav-menu").load("../nav/nav.php",); 
              $("#nav-header").load("../nav/header.php"); 
            });

            // FadeIn Content
            $('body').fadeOut(0);
            $('body').fadeIn(2000);
           
        </script>
    </body>

</html>