<?php
    // include '../back-end/back-end-report.php';
    // $result = new report(); 
    // $query = $result->managereport();
?>

<!DOCTYPE html>
<html lang="en">

<style type="text/css">
.sidebar .nav-item.active-reports .nav-link {
    font-weight: 700;
}
</style>

    <body>
        <div id="wrapper">
            <div id="nav-menu"></div>
            <div id="content-wrapper" class="d-flex flex-column">
                <div id="content">
                    <div id="nav-header"></div>

                    <div class="container-fluid">

                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800">Reports</h1>
                        </div>

                        <!-- DataTales Example -->
                        
                        <div class="card shadow mb-4 my-5">
                            <div class="card-header py-3" style="background-image: linear-gradient(to right, #f3306a , #ec7b07);">
                                <h6 class="m-0 font-weight-bold text-white">Reports</h6>
                            </div>

                            <div class="col-lg-12 my-5">
                                <form action="reports-details.php" method="POST" class="user">
                                    <div class="row">
                                        <div class="col-lg-5">
                                            <label>From Date</label>
                                            <div class="form-group">
                                                <input type="date" name="start_date" class="form-control btn-sm rounded-0" id="exampleFirstName" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-5">
                                            <label>To Date</label>
                                            <div class="form-group">
                                                <input type="date" name="end_date" class="form-control btn-sm rounded-0" id="exampleLastName" required>
                                            </div>
                                        </div>
                                        <div class="col-lg-2">
                                            <label style="opacity: 0;">Button</label>
                                            <div class="form-group">
                                                <button  class="btn form-control btn-sm btn-primary float-right" name="search">Search</button>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </form>
                            </div>   
                        </div>
                        
                    </div>

                    <!-- Copyright of Parking Reservation System -->
                    <div class="bg-white h-100 m-4 mt-5 p-3 pl-3">
                        <small>Copyright © 2021</small>
                        <small class="float-right">Parking Reservation System</small>
                    </div>
                </div>
            </div>
        </div>
        <script src="../vendor/jquery/jquery.min.js"></script>
        <script> 

            // Show Nav Menu And Header
            $(function(){
              $("#nav-menu").load("../nav/nav.php",); 
              $("#nav-header").load("../nav/header.php"); 
            });

            // FadeIn Content
            $('body').fadeOut(0);
            $('body').fadeIn(2000);
           
        </script>
    </body>

</html>