<!DOCTYPE html>
<html lang="en">

<style type="text/css">
.sidebar .nav-item.active-new-vehicle .nav-link {
    font-weight: 700;
}
</style>

    <body>
        <div id="wrapper">
            <div id="nav-menu"></div>
            <div id="content-wrapper" class="d-flex flex-column">
                <div id="content">
                    <div id="nav-header"></div>

                    <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">New Vehicle</h1>
                    </div>

                    <div class="container m-0 p-0 col-lg-4">

        <div class="card o-hidden border-1 my-5">
            <div class="card-body p-0">
                <!-- Nested Row within Card Body -->
                <div class="row">
                    <div class="col-lg-12">
                        <div>
                            <div class="text-center p-2" style="background-image: linear-gradient(to right, #f3306a , #ec7b07);">
                                <h1 class="h4 text-white" >Add New vehicle</h1>
                            </div>

                            <?php if (isset($_GET['error'])) { ?>
                                <div class="alert alert-danger" role="alert">
                                  <?php echo $_GET['error']; ?>
                                </div>
                            <?php }else if (isset($_GET['success'])) { ?>
                                <div class="alert alert-info" role="alert">
                                  <?php echo $_GET['success']; ?>
                                </div>
                            <?php } ?>
                            
                            <form action="../back-end/back-end-new-vehicle.php" method="POST" class="user m-3">
                                    <div class="form-group mb-3 mb-sm-0">
                                        <label>Full Name</label>
                                        <input type="text" name="fullname" class="form-control rounded-0" id="exampleFirstName"
                                            placeholder="Full Name..." required>
                                    </div>
                                    <div class="form-group mt-3">
                                        <label>Phone Number</label>
                                        <input type="text" name="phone_number" class="form-control rounded-0" id="exampleLastName"
                                            placeholder="Phone Number..." required>
                                    </div>
                                    <div class="form-group mb-3 mb-sm-0">
                                        <label>Park</label>
                                        <input type="text" name="park" class="form-control rounded-0" id="exampleFirstName"
                                            placeholder="Park..." required>
                                    </div>
                                    <div class="form-group mt-3">
                                        <label>Plot</label>
                                        <input type="text" name="plot" class="form-control rounded-0" id="exampleLastName"
                                            placeholder="Plot..." required>
                                    </div>
                                    <div class="form-group mb-3 mb-sm-0">
                                        <label>Model</label>
                                        <input type="text" name="model" class="form-control rounded-0" id="exampleFirstName"
                                            placeholder="Model..." required>
                                    </div>
                                    <div class="form-group mt-3">
                                        <label>Plate Number</label>
                                        <input type="text" name="plate_number" class="form-control rounded-0" id="exampleLastName"
                                            placeholder="Plate Number..." required>
                                    </div>
                                <button  class="btn btn-primary" name="new-vehicle">
                                    New Vehicle
                                </button>
                               
                            </form>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
                   

                </div>

                <div class="bg-white h-100 m-4 mt-5 p-3 pl-3">
                    <small>Copyright © 2021</small>
                    <small class="float-right">Parking Reservation System</small>
                </div>
                </div>
            </div>


        </div>
        <script src="../vendor/jquery/jquery.min.js"></script>
        <script> 

            // Show Nav Menu And Header
            $(function(){
              $("#nav-menu").load("../nav/nav.php",); 
              $("#nav-header").load("../nav/header.php"); 
            });

            // FadeIn Content
            $('body').fadeOut(0);
            $('body').fadeIn(2000);
           
        </script>
    </body>

</html>