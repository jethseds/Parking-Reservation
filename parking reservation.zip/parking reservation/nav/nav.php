<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Online Vehicle Parking Reservation System</title>

    <!-- Custom fonts for this template-->
    <link href="../vendor/fontawesome-free/css/all.min.css?v=<?php echo time() ?>" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template-->
    <link href="../css/sb-admin-2.min.css?v=<?php echo time() ?>" rel="stylesheet">
    <link href="../css/style.css?v=<?php echo time() ?>" rel="stylesheet">

</head>

<body id="page-top">

  

        <!-- Sidebar -->
        <ul class="navbar-nav sidebar sidebar-dark accordion ul" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
                <div class="sidebar-brand-text mx-3"><h1><i class="fas fa-book-reader"></i> Admin</h1></div>
            </a>

            <!-- Sidebar - Brand - Mobile -->
            <a class="two d-flex align-items-center justify-content-center" href="dashboard.php">
                <div class="sidebar-brand-text mx-3"><h1><i class="fas fa-book-reader"></i></h1></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active-dashboard">
                <a class="nav-link " href="dashboard.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Nav Item - New Vehicle -->
            <li class="nav-item active-new-vehicle">
                <a class="nav-link text-dark" href="new-vehicle.php">
                    <i class="fas fa-user-plus"></i>
                    <span>New Vehicle</span></a>
            </li>

            <!-- Nav Item - Manage Vehicle -->
            <li class="nav-item active-manage-vehicle">
                <a class="nav-link collapsed text-dark" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-tasks"></i>
                    <span>Manage Vehicle</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="py-2 collapse-inner rounded">
                        <a class="collapse-item text-dark" href="ingoing-vehicle.php">
                            <i class="fas fa-table"></i> 
                            <span>Ingoing Vehicle</span>
                        </a>
                        <a class="collapse-item text-dark" href="outgoing-vehicle.php">
                            <i class="fas fa-table"></i> 
                            <span>Outgoing Vehicle</span>
                        </a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Reports -->
            <li class="nav-item active-reports">
                <a class="nav-link text-dark" href="reports.php">
                    <i class="fas fa-calendar-alt"></i>
                    <span>Reports</span></a>
            </li>

        </ul>
        <!-- End of Sidebar -->

        

    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


</body>

</html>