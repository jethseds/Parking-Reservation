<?php
session_start();
include 'config/config.php';

class login extends Connection{
    public $sqlselect;
    public $statementselect;
    public function loginuser(){  
      if (isset($_POST['login'])) {
          $username = $_POST['username'];
          $password = $_POST['password'];
          $this->sqlselect = "SELECT * FROM tbl_admin WHERE username = ?";
          $this->statementselect = $this->conn()->prepare($this->sqlselect);
          $this->statementselect->bindParam(1, $username);
          $this->statementselect->execute([$username]);
          if ($this->statementselect->rowcount() > 0) {
            $row = $this->statementselect->fetch();
            if (password_verify($password,$row['password'])) {
              $_SESSION['admin_id'] = $row["admin_id"];
              header('location:admin/dashboard.php');
              $_SESSION['admin_id'] = $row['admin_id'];
            }else{
              header('location:login.php?error=Invalid password');
            }
          }else{
              header('location:login.php?error=Invalid username and password');
          }   
      }
    }
}
$loginrun = new login();
$loginrun->loginuser();
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <link rel="stylesheet" type="text/css" href="css/style.css">

    <title>Online Vehicle Parking Reservation System</title>
  </head>
  <body class="bg-login">

    <div class="wrapper p-5 bg-white col-lg-4">

      <?php if (isset($_GET['error'])) { ?>
        <div class="alert alert-danger" role="alert">
          <?php echo $_GET['error']; ?>
        </div>
      <?php }else if (isset($_GET['success'])) { ?>
        <div class="alert alert-info" role="alert">
          <?php echo $_GET['success']; ?>
        </div>
      <?php } ?>

      <form method="POST" class="w-100">
        <div class="form-group">
          <label for="exampleInputEmail1">Username</label>
          <input type="text" name="username" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Username">
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Password</label>
          <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
        </div>
        <div class="form-group float-right">
        <label><a href="" class="text-danger">Forgot Password?</a></label>
        </div>
        <button type="submit" name="login" class="btn form-control btn-primary">Submit</button>
      </form>

    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
